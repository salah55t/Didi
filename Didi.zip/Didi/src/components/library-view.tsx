"use client";

import { useState } from "react";
import { Gamepad2, Hand, Heart } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { METHODS } from "@/lib/methods";
import { POSITIONS } from "@/lib/positions";
import { GAMES } from "@/lib/games";
import type { Intensity } from "@/lib/types";
import { FlameLevel, MethodDetail, PositionDetail, GameDetail } from "./content-cards";

export function LibraryView() {
  const [tab, setTab] = useState("foreplay");

  return (
    <div className="space-y-5">
      <div className="space-y-1.5 text-center">
        <h2 className="text-xl font-black text-gradient-rose sm:text-2xl">مكتبة همسة الكاملة</h2>
        <p className="mx-auto max-w-lg text-sm leading-7 text-muted-foreground">
          كل الموارد التي تستعملها ليالي البرنامج في مكان واحد: 16 طريقة مداعبة، 16 وضعية،
          و12 لعبة حميمية — مرتبة حسب مستوى الجرأة.
        </p>
      </div>

      <Tabs value={tab} onValueChange={setTab} className="w-full">
        <TabsList className="mx-auto grid w-full max-w-md grid-cols-3 h-auto p-1">
          <TabsTrigger value="foreplay" className="gap-1.5 py-2 text-xs sm:text-sm">
            <Hand className="h-4 w-4" /> المداعبة (16)
          </TabsTrigger>
          <TabsTrigger value="positions" className="gap-1.5 py-2 text-xs sm:text-sm">
            <Heart className="h-4 w-4" /> الوضعيات (16)
          </TabsTrigger>
          <TabsTrigger value="games" className="gap-1.5 py-2 text-xs sm:text-sm">
            <Gamepad2 className="h-4 w-4" /> الألعاب (12)
          </TabsTrigger>
        </TabsList>

        <TabsContent value="foreplay" className="mt-5">
          <Accordion type="multiple" className="grid gap-3 md:grid-cols-2">
            {METHODS.map((m, idx) => (
              <AccordionItem
                key={m.id}
                value={m.id}
                className="glass-card rounded-2xl border-none px-4"
              >
                <AccordionTrigger className="py-3.5 hover:no-underline">
                  <span className="flex flex-wrap items-center gap-2 text-start text-sm font-extrabold">
                    <span className="text-primary">{idx + 1}.</span> {m.name}
                    <FlameLevel level={m.intensity as Intensity} size={11} />
                  </span>
                </AccordionTrigger>
                <AccordionContent className="pb-5">
                  <MethodDetail m={m} />
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </TabsContent>

        <TabsContent value="positions" className="mt-5">
          <Accordion type="multiple" className="grid gap-3 md:grid-cols-2">
            {POSITIONS.map((p, idx) => (
              <AccordionItem
                key={p.id}
                value={p.id}
                className="glass-card rounded-2xl border-none px-4"
              >
                <AccordionTrigger className="py-3.5 hover:no-underline">
                  <span className="flex flex-wrap items-center gap-2 text-start text-sm font-extrabold">
                    <span className="text-primary">{idx + 1}.</span> {p.name}
                    <FlameLevel level={p.intensity as Intensity} size={11} />
                  </span>
                </AccordionTrigger>
                <AccordionContent className="pb-5">
                  <PositionDetail p={p} />
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </TabsContent>

        <TabsContent value="games" className="mt-5">
          <Accordion type="multiple" className="grid gap-3 md:grid-cols-2">
            {GAMES.map((g, idx) => (
              <AccordionItem
                key={g.id}
                value={g.id}
                className="glass-card rounded-2xl border-none px-4"
              >
                <AccordionTrigger className="py-3.5 hover:no-underline">
                  <span className="flex flex-wrap items-center gap-2 text-start text-sm font-extrabold">
                    <span className="text-primary">{idx + 1}.</span> {g.name}
                    <FlameLevel level={g.intensity as Intensity} size={11} />
                  </span>
                </AccordionTrigger>
                <AccordionContent className="pb-5">
                  <GameDetail g={g} />
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </TabsContent>
      </Tabs>
    </div>
  );
}
