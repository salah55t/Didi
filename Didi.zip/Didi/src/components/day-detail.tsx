"use client";

import { useMemo, useState } from "react";
import {
  BedDouble,
  Check,
  Gamepad2,
  Hand,
  Heart,
  MessageCircle,
  Moon,
  Sparkles,
  Timer,
  Wine,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { cn } from "@/lib/utils";
import { buildDayPlan, buildProtocol, LEVEL_NAMES, ROUNDS_SHORT, weekThemeOf } from "@/lib/program";
import { pickMethod, pickPosition, pickGame } from "@/lib/program";
import type { Intensity } from "@/lib/types";
import { FlameLevel, MethodDetail, PositionDetail, GameDetail } from "./content-cards";

const STAGE_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  MessageCircle,
  Sparkles,
  Wine,
  Hand,
  Gamepad2,
  Heart,
  BedDouble,
  Moon,
};

export function DayDetail({
  day,
  done,
  onToggleDone,
  compact = false,
}: {
  day: number;
  done?: boolean;
  onToggleDone?: () => void;
  compact?: boolean;
}) {
  const plan = useMemo(() => buildDayPlan(day), [day]);
  const stages = useMemo(() => buildProtocol(plan), [plan]);
  const m1 = pickMethod(plan.foreplayMethodIds[0]);
  const m2 = pickMethod(plan.foreplayMethodIds[1]);
  const p1 = pickPosition(plan.positionIds[0]);
  const p2 = pickPosition(plan.positionIds[1]);
  const game = pickGame(plan.gameId);
  const theme = weekThemeOf(day);

  return (
    <div className="space-y-6">
      {/* رأس اليوم */}
      <header className="space-y-3 text-center">
        <div className="flex flex-wrap items-center justify-center gap-2">
          <Badge variant="outline" className="border-primary/40 text-primary">
            الليلة {day} من 30
          </Badge>
          <Badge variant="outline" className="border-border text-muted-foreground">
            الأسبوع {theme.week}: {theme.theme}
          </Badge>
          {plan.special && (
            <Badge className="border-0 bg-gradient-to-l from-rose-500 to-amber-400 text-white">
              <Sparkles className="ms-1 h-3 w-3" /> {plan.special}
            </Badge>
          )}
        </div>
        <h2 className="text-2xl font-black tracking-tight text-gradient-rose sm:text-3xl">
          {plan.title}
        </h2>
        <p className="mx-auto max-w-md text-sm leading-7 text-muted-foreground">{plan.focus}</p>
      </header>

      {plan.specialNote && (
        <div className="rounded-2xl border border-amber-500/30 bg-gradient-to-l from-amber-500/15 to-rose-500/10 p-4">
          <p className="text-sm font-semibold leading-7 text-amber-100">{plan.specialNote}</p>
        </div>
      )}

      {/* شريط الإحصاءات */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="glass-card flex flex-col items-center gap-2 rounded-2xl p-3.5">
          <span className="text-[11px] font-bold text-muted-foreground">مستوى الجرأة</span>
          <FlameLevel level={plan.level} size={16} showLabel />
        </div>
        <div className="glass-card flex flex-col items-center justify-center gap-2 rounded-2xl p-3.5 text-center">
          <span className="text-[11px] font-bold text-muted-foreground">عدد الجولات</span>
          <span className="flex items-center gap-1.5 text-sm font-bold text-foreground">
            <Heart className="h-4 w-4 shrink-0 text-primary" /> {ROUNDS_SHORT[plan.level]}
          </span>
        </div>
        <div className="glass-card flex flex-col items-center gap-2 rounded-2xl p-3.5">
          <span className="text-[11px] font-bold text-muted-foreground">مدة الليلة</span>
          <span className="flex items-center gap-1.5 text-sm font-bold text-foreground">
            <Timer className="h-4 w-4 text-primary" /> {plan.totalDuration}
          </span>
        </div>
        <div className="glass-card flex flex-col items-center gap-2 rounded-2xl p-3.5">
          <span className="text-[11px] font-bold text-muted-foreground">طابع المستوى</span>
          <span className="flex items-center gap-1.5 text-sm font-bold text-foreground">
            <Zap className="h-4 w-4 text-primary" /> {LEVEL_NAMES[plan.level]}
          </span>
        </div>
      </div>

      {/* البروتوكول */}
      <section className="space-y-4">
        <h3 className="flex items-center gap-2 text-lg font-extrabold text-foreground">
          <Sparkles className="h-5 w-5 text-primary" />
          البروتوكول المتكامل — من البداية إلى النهاية
        </h3>
        <div className="relative space-y-3 ps-1">
          <div className="protocol-line inset-y-2" aria-hidden />
          {stages.map((stage, i) => {
            const Icon = STAGE_ICONS[stage.icon] ?? Sparkles;
            return (
              <article key={i} className="relative flex gap-4">
                <div className="relative z-10 mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-primary/40 bg-card rose-glow">
                  <Icon className="h-4 w-4 text-primary" />
                </div>
                <div className="glass-card flex-1 rounded-2xl p-4">
                  <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                    <h4 className="text-sm font-extrabold text-foreground">
                      <span className="ms-1 text-primary">{i + 1}.</span> {stage.title}
                    </h4>
                    <Badge
                      variant="outline"
                      className="border-primary/30 text-[11px] text-primary"
                    >
                      {stage.duration}
                    </Badge>
                  </div>
                  <ul className="space-y-1.5">
                    {stage.details.map((d, j) => (
                      <li
                        key={j}
                        className="flex gap-2 text-[13px] leading-6 text-foreground/80"
                      >
                        <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary/60" />
                        {d}
                      </li>
                    ))}
                  </ul>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* بطاقات التفاصيل */}
      {!compact && (
        <section className="space-y-3">
          <h3 className="flex items-center gap-2 text-lg font-extrabold text-foreground">
            <Hand className="h-5 w-5 text-primary" />
            تفاصيل الليلة بالكامل
          </h3>
          <Accordion type="multiple" className="space-y-3">
            <AccordionItem
              value="method1"
              className="glass-card rounded-2xl border-none px-4"
            >
              <AccordionTrigger className="py-4 hover:no-underline">
                <span className="flex flex-wrap items-center gap-2 text-start text-sm font-extrabold">
                  <span className="text-primary">المداعبة الأساسية:</span> {m1.name}
                  <FlameLevel level={m1.intensity as Intensity} size={12} />
                </span>
              </AccordionTrigger>
              <AccordionContent className="pb-5">
                <MethodDetail m={m1} />
              </AccordionContent>
            </AccordionItem>

            <AccordionItem
              value="method2"
              className="glass-card rounded-2xl border-none px-4"
            >
              <AccordionTrigger className="py-4 hover:no-underline">
                <span className="flex flex-wrap items-center gap-2 text-start text-sm font-extrabold">
                  <span className="text-primary">مداعبة إضافية:</span> {m2.name}
                  <FlameLevel level={m2.intensity as Intensity} size={12} />
                </span>
              </AccordionTrigger>
              <AccordionContent className="pb-5">
                <MethodDetail m={m2} />
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="game" className="glass-card rounded-2xl border-none px-4">
              <AccordionTrigger className="py-4 hover:no-underline">
                <span className="flex flex-wrap items-center gap-2 text-start text-sm font-extrabold">
                  <span className="text-primary">لعبة المداعبة:</span> {game.name}
                  <FlameLevel level={game.intensity as Intensity} size={12} />
                </span>
              </AccordionTrigger>
              <AccordionContent className="pb-5">
                <GameDetail g={game} />
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="pos1" className="glass-card rounded-2xl border-none px-4">
              <AccordionTrigger className="py-4 hover:no-underline">
                <span className="flex flex-wrap items-center gap-2 text-start text-sm font-extrabold">
                  <span className="text-primary">الجولة الأولى:</span> {p1.name}
                  <FlameLevel level={p1.intensity as Intensity} size={12} />
                </span>
              </AccordionTrigger>
              <AccordionContent className="pb-5">
                <PositionDetail p={p1} />
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="pos2" className="glass-card rounded-2xl border-none px-4">
              <AccordionTrigger className="py-4 hover:no-underline">
                <span className="flex flex-wrap items-center gap-2 text-start text-sm font-extrabold">
                  <span className="text-primary">الجولة الثانية:</span> {p2.name}
                  <FlameLevel level={p2.intensity as Intensity} size={12} />
                </span>
              </AccordionTrigger>
              <AccordionContent className="pb-5">
                <PositionDetail p={p2} />
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </section>
      )}

      {/* نصيحة اليوم */}
      <section className="rounded-2xl border border-primary/25 bg-primary/10 p-4">
        <h4 className="mb-1.5 flex items-center gap-2 text-sm font-extrabold text-primary">
          <Sparkles className="h-4 w-4" /> نصيحة ليلة اليوم
        </h4>
        <p className="text-sm leading-7 text-foreground/85">{plan.extraTip}</p>
      </section>

      {/* زر الإتمام */}
      {onToggleDone && (
        <div className="flex justify-center pb-2">
          <Button
            size="lg"
            onClick={onToggleDone}
            className={cn(
              "min-h-12 gap-2 px-8 text-base font-extrabold",
              done
                ? "bg-emerald-600/90 text-white hover:bg-emerald-600"
                : "bg-gradient-to-l from-rose-600 to-amber-500 text-white hover:opacity-90"
            )}
          >
            <Check className="h-5 w-5" />
            {done ? "تمت هذه الليلة بنجاح — إلغاء؟" : "أتممنا ليلة اليوم"}
          </Button>
        </div>
      )}
    </div>
  );
}
