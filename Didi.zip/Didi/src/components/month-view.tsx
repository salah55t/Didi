"use client";

import { useState } from "react";
import { CalendarDays, Check, Heart } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { buildDayPlan, WEEKS } from "@/lib/program";
import type { Intensity } from "@/lib/types";
import { DayDetail } from "./day-detail";

export function MonthView({
  activeDay,
  completedDays,
  onToggleDone,
}: {
  activeDay: number;
  completedDays: number[];
  onToggleDone: (day: number) => void;
}) {
  const [openDay, setOpenDay] = useState<number | null>(null);
  const doneSet = new Set(completedDays);

  return (
    <div className="space-y-8">
      {WEEKS.map((w) => (
        <section key={w.week} className="space-y-4">
          <header className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="flex items-center gap-2 text-lg font-extrabold text-gradient-rose">
                <CalendarDays className="h-5 w-5 text-primary" />
                الأسبوع {w.week}: {w.theme}
              </h3>
              <span className="text-xs font-semibold text-muted-foreground">
                (اليوم {w.from} – {w.to})
              </span>
            </div>
            <p className="max-w-2xl text-sm leading-7 text-muted-foreground">{w.description}</p>
          </header>

          <div className="grid grid-cols-4 gap-2.5 sm:grid-cols-7">
            {Array.from({ length: w.to - w.from + 1 }, (_, i) => w.from + i).map((day) => {
              const plan = buildDayPlan(day);
              const isDone = doneSet.has(day);
              const isActive = day === activeDay;
              return (
                <button
                  key={day}
                  onClick={() => setOpenDay(day)}
                  className={cn(
                    "group relative flex min-h-24 flex-col items-center justify-center gap-1.5 rounded-2xl border p-2.5 text-center transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/60 hover:shadow-lg",
                    isDone
                      ? "border-emerald-500/40 bg-emerald-500/10"
                      : "glass-card border-border/60",
                    isActive && "ring-2 ring-primary ring-offset-2 ring-offset-background"
                  )}
                  aria-label={`تفاصيل الليلة ${day}: ${plan.title}`}
                >
                  {isDone && (
                    <span className="absolute end-1.5 top-1.5 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-emerald-500 p-0.5">
                      <Check className="h-3 w-3 text-white" strokeWidth={3} />
                    </span>
                  )}
                  {isActive && (
                    <span className="absolute start-1.5 top-1.5 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-primary p-0.5">
                      <Heart className="h-2.5 w-2.5 text-white" fill="white" />
                    </span>
                  )}
                  <span
                    className="text-lg font-black"
                    style={{ color: isDone ? "#6ee7b7" : undefined }}
                  >
                    {day}
                  </span>
                  <span className="line-clamp-2 text-[10px] font-semibold leading-4 text-foreground/75">
                    {plan.title}
                  </span>
                  <span className="flex items-center gap-0.5" dir="ltr">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <span
                        key={i}
                        className="h-1 w-2.5 rounded-full"
                        style={{
                          backgroundColor:
                            i <= plan.level
                              ? ["#d9a7b0", "#e08fa4", "#e2737f", "#e5564a", "#ff7a3d"][plan.level - 1]
                              : "rgba(255,255,255,0.12)",
                        }}
                      />
                    ))}
                  </span>
                </button>
              );
            })}
          </div>
        </section>
      ))}

      {/* نافذة تفاصيل اليوم */}
      <Dialog open={openDay !== null} onOpenChange={(o) => !o && setOpenDay(null)}>
        <DialogContent className="nice-scroll max-h-[85vh] overflow-y-auto border-border/60 bg-card sm:max-w-2xl">
          {openDay !== null && (
            <>
              <DialogHeader className="sr-only">
                <DialogTitle>تفاصيل الليلة {openDay}</DialogTitle>
                <DialogDescription>البروتوكول الكامل لليلة {openDay} من البرنامج</DialogDescription>
              </DialogHeader>
              <DayDetail
                day={openDay}
                done={doneSet.has(openDay)}
                onToggleDone={() => {
                  onToggleDone(openDay);
                  setOpenDay(null);
                }}
              />
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
