"use client";

import { Flame, Clock, Target, Lightbulb, Ban } from "lucide-react";
import { cn } from "@/lib/utils";
import { LEVEL_COLORS, LEVEL_NAMES } from "@/lib/program";
import type { ForeplayMethod, Game, Intensity, Position } from "@/lib/types";

/* ------------------------------------------------------------------ */
/*  شعلة المستوى                                                       */
/* ------------------------------------------------------------------ */

export function FlameLevel({
  level,
  size = 14,
  showLabel = false,
  className,
}: {
  level: Intensity;
  size?: number;
  showLabel?: boolean;
  className?: string;
}) {
  const color = LEVEL_COLORS[level];
  return (
    <span
      className={cn("inline-flex items-center gap-1.5", className)}
      title={`مستوى الجرأة: ${level} من 5 — ${LEVEL_NAMES[level]}`}
    >
      <span className="inline-flex items-center gap-0.5" dir="ltr">
        {[1, 2, 3, 4, 5].map((i) => (
          <Flame
            key={i}
            width={size}
            height={size}
            style={{
              color: i <= level ? color : "rgba(255,255,255,0.14)",
              fill: i <= level ? color : "transparent",
            }}
          />
        ))}
      </span>
      {showLabel && (
        <span className="text-xs font-semibold" style={{ color }}>
          {LEVEL_NAMES[level]}
        </span>
      )}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  رقاقة معلومات صغيرة                                                */
/* ------------------------------------------------------------------ */

export function Chip({
  icon: Icon,
  children,
  className,
}: {
  icon?: React.ComponentType<{ className?: string }>;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-border/60 bg-secondary/50 px-3 py-1 text-xs font-semibold text-secondary-foreground",
        className
      )}
    >
      {Icon && <Icon className="h-3.5 w-3.5 text-primary" />}
      {children}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  بطاقة تفاصيل طريقة مداعبة                                          */
/* ------------------------------------------------------------------ */

export function MethodDetail({ m }: { m: ForeplayMethod }) {
  return (
    <div className="space-y-4">
      <p className="text-sm leading-7 text-foreground/90">{m.description}</p>
      <div>
        <h5 className="mb-2 flex items-center gap-1.5 text-sm font-bold text-primary">
          <Clock className="h-4 w-4" /> خطوات التنفيذ ({m.duration})
        </h5>
        <ol className="space-y-2">
          {m.steps.map((s, i) => (
            <li key={i} className="flex gap-2.5 text-sm leading-7 text-foreground/85">
              <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/15 text-[11px] font-bold text-primary">
                {i + 1}
              </span>
              {s}
            </li>
          ))}
        </ol>
      </div>
      <div className="flex gap-2.5 rounded-xl border border-amber-500/20 bg-amber-500/10 p-3">
        <Lightbulb className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
        <p className="text-sm leading-7 text-amber-100/90">{m.tip}</p>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  بطاقة تفاصيل وضعية                                                 */
/* ------------------------------------------------------------------ */

export function PositionDetail({ p }: { p: Position }) {
  return (
    <div className="space-y-4">
      <p className="text-sm leading-7 text-foreground/90">{p.description}</p>
      <div className="flex gap-2.5 rounded-xl border border-primary/20 bg-primary/10 p-3">
        <Target className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
        <div>
          <span className="text-xs font-bold text-primary">لماذا هذه الوضعية؟</span>
          <p className="mt-1 text-sm leading-7 text-foreground/85">{p.why}</p>
        </div>
      </div>
      <div className="flex gap-2.5 rounded-xl border border-amber-500/20 bg-amber-500/10 p-3">
        <Lightbulb className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
        <p className="text-sm leading-7 text-amber-100/90">{p.tip}</p>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  بطاقة تفاصيل لعبة                                                  */
/* ------------------------------------------------------------------ */

export function GameDetail({ g }: { g: Game }) {
  return (
    <div className="space-y-4">
      <p className="text-sm leading-7 text-foreground/90">{g.description}</p>
      <div className="flex flex-wrap gap-2">
        <Chip icon={Clock}>المدة: {g.duration}</Chip>
        <Chip icon={Lightbulb}>الأدوات: {g.tools}</Chip>
      </div>
      <div>
        <h5 className="mb-2 text-sm font-bold text-primary">طريقة اللعب</h5>
        <ol className="space-y-2">
          {g.howTo.map((s, i) => (
            <li key={i} className="flex gap-2.5 text-sm leading-7 text-foreground/85">
              <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/15 text-[11px] font-bold text-primary">
                {i + 1}
              </span>
              {s}
            </li>
          ))}
        </ol>
      </div>
      <div className="flex gap-2.5 rounded-xl border border-rose-500/25 bg-rose-500/10 p-3">
        <Ban className="mt-0.5 h-4 w-4 shrink-0 text-rose-300" />
        <p className="text-sm leading-7 text-rose-100/90">
          <span className="font-bold">قانون اللعبة: </span>
          {g.rule}
        </p>
      </div>
    </div>
  );
}
