"use client";

import type { Progress } from "./types";

const STORAGE_KEY = "hamsa-progress-v1";

const DEFAULT_PROGRESS: Progress = {
  startDate: null,
  completedDays: [],
};

export function loadProgress(): Progress {
  if (typeof window === "undefined") return DEFAULT_PROGRESS;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_PROGRESS;
    const parsed = JSON.parse(raw) as Partial<Progress>;
    return {
      startDate: typeof parsed.startDate === "string" ? parsed.startDate : null,
      completedDays: Array.isArray(parsed.completedDays)
        ? parsed.completedDays.filter((n) => typeof n === "number" && n >= 1 && n <= 30)
        : [],
    };
  } catch {
    return DEFAULT_PROGRESS;
  }
}

export function saveProgress(progress: Progress) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch {
    // ignore quota errors
  }
}

/** تاريخ اليوم بصيغة YYYY-MM-DD بالتوقيت المحلي */
export function todayISO(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/** عدد الأيام المنقضية بين تاريخي (محلي، بدون ساعات) */
export function daysBetween(fromISO: string, toISO: string): number {
  const [fy, fm, fd] = fromISO.split("-").map(Number);
  const [ty, tm, td] = toISO.split("-").map(Number);
  const from = new Date(fy, fm - 1, fd).getTime();
  const to = new Date(ty, tm - 1, td).getTime();
  return Math.round((to - from) / 86_400_000);
}

/** رقم اليوم الحالي في البرنامج (1..30) أو 1 إذا لم يبدأ */
export function currentDayOf(progress: Progress): number {
  if (!progress.startDate) return 1;
  const diff = daysBetween(progress.startDate, todayISO());
  return Math.min(30, Math.max(1, diff + 1));
}

/** أطول سلسلة متتالية مكتملة */
export function bestStreak(completedDays: number[]): number {
  const set = new Set(completedDays);
  let best = 0;
  for (let d = 1; d <= 30; d++) {
    if (!set.has(d)) continue;
    let len = 1;
    while (set.has(d + len)) len++;
    if (len > best) best = len;
  }
  return best;
}

/** السلسلة الحالية المنتهية عند آخر يوم مكتمل */
export function currentStreak(completedDays: number[]): number {
  if (completedDays.length === 0) return 0;
  const sorted = [...completedDays].sort((a, b) => a - b);
  const last = sorted[sorted.length - 1];
  let streak = 0;
  for (let d = last; d >= 1; d--) {
    if (sorted.includes(d)) streak++;
    else break;
  }
  return streak;
}
