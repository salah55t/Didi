import type {
  DayPlan,
  Intensity,
  ProtocolStage,
  WeekTheme,
} from "./types";
import { METHODS } from "./methods";
import { POSITIONS } from "./positions";
import { GAMES } from "./games";

/* ------------------------------------------------------------------ */
/*  أسابيع البرنامج الخمسة                                             */
/* ------------------------------------------------------------------ */

export const WEEKS: WeekTheme[] = [
  {
    week: 1,
    from: 1,
    to: 7,
    theme: "إعادة الاكتشاف",
    description:
      "تبدأ الرحلة بهدوء وثقة: إعادة تعريف اللمسة والتقبيل وبناء الأجواء من جديد. الجرأة منخفضة والهدف إشعال الشرارة الأولى بلطف.",
  },
  {
    week: 2,
    from: 8,
    to: 14,
    theme: "التواصل العميق",
    description:
      "ترتفع الحرارة تدريجياً: مداعبات أطول، كلمات أجرأ، وأولى التجارب المريحة للجسدين معاً.",
  },
  {
    week: 3,
    from: 15,
    to: 21,
    theme: "كسر الروتين",
    description:
      "الأسبوع المغامر: وضعيات جديدة، مواقع مختلفة في المنزل، وألعاب تكسر الحرج نهائياً وتفتح باب الصراحة.",
  },
  {
    week: 4,
    from: 22,
    to: 28,
    theme: "الذروة الجسورة",
    description:
      "قمة الشهر: أعلى مستويات الجرأة، ألعاب تصاعدية، وليالٍ طويلة تعتمد على كل ما تعلّمتماه سابقاً.",
  },
  {
    week: 5,
    from: 29,
    to: 30,
    theme: "الختام الذهبي",
    description:
      "تحية النهاية: ذروة امتنان واحتفال بما بنيتهما خلال ثلاثين يوماً، وخريطة لأشهر ليلتين قادمتين.",
  },
];

export function weekOf(day: number): number {
  if (day <= 7) return 1;
  if (day <= 14) return 2;
  if (day <= 21) return 3;
  if (day <= 28) return 4;
  return 5;
}

/* ------------------------------------------------------------------ */
/*  نصوص حسب المستوى                                                   */
/* ------------------------------------------------------------------ */

export const LEVEL_NAMES: Record<Intensity, string> = {
  1: "هادئ ولطيف",
  2: "دافئ متدرج",
  3: "متوسط متجدد",
  4: "جسور",
  5: "اشتعل الكل",
};

export const LEVEL_COLORS: Record<Intensity, string> = {
  1: "#d9a7b0",
  2: "#e08fa4",
  3: "#e2737f",
  4: "#e5564a",
  5: "#ff7a3d",
};

const ROUNDS_TEXT: Record<Intensity, string> = {
  1: "جولة واحدة طويلة (20–25 دقيقة) — الجودة قبل الكمية",
  2: "جولتان متوسطتان مع استراحة قصيرة بينهما",
  3: "جولتان مكتملتان مع مداعبة موسّعة بين الجولتين",
  4: "جولتان إلى ثلاث حسب الطاقة، مع تصاعد واضح في الإيقاع",
  5: "ثلاث جولات متصاعدة الشدة مع عناية إضافية بعد الثالثة",
};

export const ROUNDS_SHORT: Record<Intensity, string> = {
  1: "جولة واحدة طويلة",
  2: "جولتان متوسطتان",
  3: "جولتان + مداعبة بينهما",
  4: "2–3 جولات متصاعدة",
  5: "3 جولات كاملة",
};

const DURATION_TEXT: Record<Intensity, string> = {
  1: "ساعة تقريباً",
  2: "ساعة ونصف تقريباً",
  3: "ساعتان تقريباً",
  4: "ساعتان أو أكثر",
  5: "ساعتان ونصف — ليلة كاملة",
};

/* ------------------------------------------------------------------ */
/*  عناوين الأيام وأهدافها                                             */
/* ------------------------------------------------------------------ */

const DAY_META: { title: string; focus: string }[] = [
  { title: "بداية الحكاية", focus: "إعادة تعريف التقبيل والبداية الهادئة" },
  { title: "نظرة جديدة", focus: "استعادة نظرة الاستحقاق: انظر إلى شريكك كأنه أول مرة" },
  { title: "لغة اللمسة", focus: "اكتشاف المناطق التي يعشقها جسد شريكك" },
  { title: "همس الأذنين", focus: "قوة الصوت القريب والكلمة المحفّزة" },
  { title: "حرير البدايات", focus: "اللعب بالتأخير والملامسة غير المباشرة" },
  { title: "نبض متقارب", focus: "مزامنة التنفس والإيقاع بينكما" },
  { title: "ليلة الشموع والبخار", focus: "تجديد الطاقة بمكان مختلف تماماً: الحمّام" },
  { title: "خريطة الجسد", focus: "رسم خريطة حسّية كاملة بلا استثناءات" },
  { title: "صوت ورغبة", focus: "التعبير عن الرغبات بكلمات صريحة محترمة" },
  { title: "تحت ضوء القمر", focus: "إطالة المداعبة إلى ضعف المعتاد" },
  { title: "جسر الثقة", focus: "لعب الثقة وعصب العينين" },
  { title: "مذاق مزدوج", focus: "دمج المذاق واللمسة في تجربة واحدة" },
  { title: "رقص الأرواح", focus: "التوافق الحركي والإيقاعي في وضعيات متقابلة" },
  { title: "ليلة منتصف الطريق", focus: "احتفال بالنصف الأول وأول تقنية متقدمة" },
  { title: "حدود جديدة", focus: "الدخول الأول لعالم الجرأة المتوسطة العالية" },
  { title: "عطر المغامرة", focus: "تغيير مواقع اللقاء داخل المنزل" },
  { title: "سر المكان", focus: "زاوية عمق جديدة من حافة السرير" },
  { title: "توقيت مختلف", focus: "قلب التوقيت المعتاد: ليلة مبكرة غير محسوبة" },
  { title: "ليلة تبادل الأدوار", focus: "انعكاس الأدوار كاملاً: من يبادر اليوم؟" },
  { title: "موجة تلو موجة", focus: "تقنية التوقف والاستئناف في الجولات" },
  { title: "مرآة الشغف", focus: "وضعيات الانعكاس والتحكم الكامل للزوجة" },
  { title: "إيقاع أسرع", focus: "الجمع بين الإيقاع السريع والمداعبة المستمرة" },
  { title: "فراشة الحرير", focus: "الأقمشة والنسيج في خدمة الإثارة" },
  { title: "عمق الإحساس", focus: "وضعيات العمق الأعلى مع تحكم كامل بالبطء" },
  { title: "صعود القمة", focus: "أول ليلة في أعلى مستويات الجرأة" },
  { title: "رغبة جسورة", focus: "قول الرغبة الأجرأ التي تأخرت طويلاً" },
  { title: "ليلة المفاجآت", focus: "كل طرف يجهّز مفاجأة صغيرة للآخر" },
  { title: "ذروة الأسبوع", focus: "الليلة الثلاثية الكاملة بأعلى طاقة" },
  { title: "ثمرة الشهر", focus: "دمج أجمل ما اكتشفتماه في ليلة واحدة" },
  { title: "ليلة الامتنان الكبرى", focus: "خلاصة الرحلة وعقد الليل القادم" },
];

/* ------------------------------------------------------------------ */
/*  نصائح متدوالة                                                      */
/* ------------------------------------------------------------------ */

const TIPS = [
  "لا تستعجل النهاية: كل دقيقة تأخير مقصود تضاعف قيمة اللحظة الأخيرة.",
  "الماء صديقك: كوب ماء قبل الجولة وبعدها يحسّن الطاقة والتعافي.",
  "الصمت ليس ذهباً دائماً: همستك وتنفّسك ومديحك تجعل شريكك يشعر بالنجاح.",
  "لا تقارن الليلة بأخرى: كل لقاء له شخصيته الخاصة — استقبله كما هو.",
  "المديح الصادق بعد اللقاء أقوى من أي مداعبة قبله — لا تُبخله عليه.",
  "الراحة جزء من البرنامج: إن كان الجسد متعباً اجعل الليلة قبلاتٍ وحضناً فقط.",
  "غيّر شيئاً واحداً فقط في كل ليلة — التغيير الكامل المفاجئ يربك أكثر مما يثير.",
  "نظافة الفم والجسد قبل اللقاء ليست رفاهية — إنها أول قواعد الاحترام الحميمي.",
  "الهاتف خارج الغرفة: ساعة كاملة من الانتباه الكامل أجمل هدية لشريكك.",
  "اسألا بعد كل ليلة: «ما أكثر شيء استمتعتِ به؟» — إجاباتكما خريطة الليل القادم.",
  "الإضاءة الخافتة ليست إخفاءً بل إبرازاً: الظلال تلمّح أكثر مما تكشف الأضواء الساطعة.",
  "الرغبة أحياناً تتبع الفعل: ابدأ المداعبة حتى لو لم يكن الحماس مكتملاً — الشغف غالباً يأتي في الطريق.",
  "خصصا دقيقة قبل النوم للامتنان الصامت: أنتما فريق ينجح معاً أو لا.",
  "لا تحمل نية الأداء المثالي بل نية الاستمتاع المشترك — الفرق بينهما جوهري.",
  "قبل ساعتين من موعد الليلة ابتعدا عن الجدال والمشاغلات الثقيلة حفاظاً على المزاج.",
];

/* ------------------------------------------------------------------ */
/*  الليالي الخاصة                                                     */
/* ------------------------------------------------------------------ */

interface SpecialDay {
  level: Intensity;
  foreplayMethodIds: string[];
  positionIds: string[];
  gameId: string;
  special: string;
  specialNote: string;
}

const SPECIALS: Record<number, SpecialDay> = {
  7: {
    level: 2,
    foreplayMethodIds: ["m6", "m9"],
    positionIds: ["p3", "p14"],
    gameId: "g8",
    special: "ليلة خاصة: البخار والشموع",
    specialNote:
      "الليلة كاملة تبدأ من الحمّام لا من غرفة النوم: استحمام مشترك بطقس كامل ثم انتقال تدريجي. اجعل الهاتف خارج البيت قليلاً اليوم.",
  },
  14: {
    level: 3,
    foreplayMethodIds: ["m14", "m4"],
    positionIds: ["p4", "p2"],
    gameId: "g2",
    special: "ليلة منتصف الطريق",
    specialNote:
      "أكملتما نصف البرنامج! احتفلا بتقدّمكما: جرّبا أول تقنية متقدمة الليلة (التوقف والاستئناف) وسجّلا ما أعجبكما في النصف الأول.",
  },
  19: {
    level: 4,
    foreplayMethodIds: ["m11", "m12"],
    positionIds: ["p13", "p7"],
    gameId: "g9",
    special: "ليلة تبادل الأدوار",
    specialNote:
      "انعكاس كامل: من يبادر عادة اليوم يُنفّذ، ومن ينفّذ اليوم يبادر. اكتشفا كيف يبدو الطرف الآخر في دورك — قد تنكشف عنك رغبات جديدة.",
  },
  28: {
    level: 5,
    foreplayMethodIds: ["m14", "m13"],
    positionIds: ["p16", "p5"],
    gameId: "g10",
    special: "ليلة الذروة الكبرى",
    specialNote:
      "قمة البرنامج كله: أطول مداعبة، أعلى جرأة، وثلاث جولات كاملة. جهّزا الليلة من الصباح — رسائل، تجهيزات، وانتظار مقصود.",
  },
  30: {
    level: 5,
    foreplayMethodIds: ["m10", "m2"],
    positionIds: ["p9", "p1"],
    gameId: "g3",
    special: "ليلة الامتنان الكبرى — ختام البرنامج",
    specialNote:
      "الختام الذهبي: افتتحا الليلة بذكر أفضل ثلاث ليالٍ في البرنامج وما تعلّمتماه منها، ثم عقدا اتفاق الليل القادم: ما الذي سنحافظ عليه؟ وما الذي سنجرّبه؟",
  },
};

/* ------------------------------------------------------------------ */
/*  مولّد خطة اليوم                                                    */
/* ------------------------------------------------------------------ */

function pickMethod(id: string) {
  return METHODS.find((m) => m.id === id)!;
}
function pickPosition(id: string) {
  return POSITIONS.find((p) => p.id === id)!;
}
function pickGame(id: string) {
  return GAMES.find((g) => g.id === id)!;
}

export function buildDayPlan(day: number): DayPlan {
  const meta = DAY_META[day - 1];
  const week = weekOf(day);
  const special = SPECIALS[day];

  /*
    مستوى اليوم: قاعدة كل أسبوع ترتفع درجة، مع «ليلة صعود» كل ثلاثة أيام،
    و«ليلة تنفّس» كل خمسة أيام تعود بمستوى قاعدة الأسبوع.
    الليالي الخاصة لها مستواها المخصص.
  */
  let finalLevel: Intensity;
  if (special) {
    finalLevel = special.level;
  } else {
    const weekBase: Record<number, number> = { 1: 1, 2: 2, 3: 3, 4: 4, 5: 5 };
    const bump = day % 3 === 0 ? 1 : 0;
    const computed = Math.min(5, weekBase[week] + bump);
    finalLevel = (day % 5 === 0 ? weekBase[week] : computed) as Intensity;
  }

  // اختيار المحتوى حسب المستوى مع دوران لا يتكرر
  const methodPool = METHODS.filter((m) => m.intensity <= finalLevel);
  const primary = special ? pickMethod(special.foreplayMethodIds[0]) : methodPool[(day - 1) % methodPool.length];
  const secondary = special
    ? pickMethod(special.foreplayMethodIds[1])
    : methodPool[(day + 4) % methodPool.length] === primary
      ? methodPool[(day + 5) % methodPool.length]
      : methodPool[(day + 4) % methodPool.length];

  const exactPool = POSITIONS.filter((p) => p.intensity === finalLevel);
  const underPool = POSITIONS.filter((p) => p.intensity <= finalLevel);
  const p1 = special
    ? pickPosition(special.positionIds[0])
    : exactPool.length > 0
      ? exactPool[(day - 1) % exactPool.length]
      : underPool[(day - 1) % underPool.length];
  const p2 = special
    ? pickPosition(special.positionIds[1])
    : underPool[(day * 7 + 3) % underPool.length] === p1
      ? underPool[(day * 7 + 4) % underPool.length]
      : underPool[(day * 7 + 3) % underPool.length];

  const gamePool = GAMES.filter((g) => g.intensity <= finalLevel);
  const game = special ? pickGame(special.gameId) : gamePool[(day - 1) % gamePool.length];

  return {
    day,
    week,
    level: finalLevel,
    title: meta.title,
    focus: meta.focus,
    rounds: ROUNDS_TEXT[finalLevel],
    totalDuration: DURATION_TEXT[finalLevel],
    foreplayMethodIds: [primary.id, secondary.id],
    positionIds: [p1.id, p2.id],
    gameId: game.id,
    extraTip: TIPS[(day - 1) % TIPS.length],
    special: special?.special,
    specialNote: special?.specialNote,
  };
}

/* ------------------------------------------------------------------ */
/*  بروتوكول الليلة الكامل                                             */
/* ------------------------------------------------------------------ */

export function buildProtocol(plan: DayPlan): ProtocolStage[] {
  const m1 = pickMethod(plan.foreplayMethodIds[0]);
  const m2 = pickMethod(plan.foreplayMethodIds[1]);
  const p1 = pickPosition(plan.positionIds[0]);
  const p2 = pickPosition(plan.positionIds[1]);
  const game = pickGame(plan.gameId);
  const L = plan.level;

  const signal: string[] = [
    "أرسل رسالة قصيرة مثيرة تخبر شريكك بليلة الليلة دون كشف التفاصيل كلها",
    "تلميحة صوتية أو نظرة طويلة عند أول لقاء في البيت",
    "اتفقوا على موعد الليلة وتأكدوا من خلوّه من المشتتات والمواعيد",
  ];
  if (L >= 4) signal.push("أضف وعداً جسوراً صغيراً واحداً يزيد الترقب طوال اليوم");

  const setup: string[] = [
    "إضاءة خافتة أو شمعة واحدة، والهاتف على الصامت تماماً خارج الغرفة",
    "موسيقى هادئة منخفضة وعطر موحّد (فانيلا، عنبر، أو ياسمين)",
    "درجة حرارة الغرفة معتدلة، وجهّزا الوسائد الإضافية والمناشف والزيوت",
  ];
  if (L >= 3) setup.push("جهّزا أدوات لعبة الليلة مسبقاً حتى لا تُكسر الجلسة للبحث عنها");

  const opening: string[] = [
    "مشروب خفيف وحديث عن ذكرى جميلة مشتركة — لا حديث مهام أو أطفال",
    "تقافز على أغنية بطيئة أو جلسة متلاصقة على الأريكة",
    "ابدأ بلمسات عامة فقط: يدان، كتف، شعر — دون استعجال",
    "اتفقوا على كلمة توقف تحترم الطرفان فوراً — الرضا المتبادل أولاً دائماً",
  ];

  const round1: string[] = [
    p1.description,
    p1.tip,
    L >= 4
      ? "الإيقاع: ابدأ هادئاً ثم ازداد تدريجياً مع استماعك المستمر لردود فعل شريكك"
      : "الإيقاع: بطيء ومقصود، حافظا على التواصل البصري قدر الإمكان",
  ];

  const breakRound2: string[] = [
    "خمس دقائق استراحة: رشفة ماء، حضن جانبي، همسة امتنان — دون حديث يومي",
    p2.description,
    p2.tip,
    plan.rounds,
  ];
  if (L >= 3) breakRound2.push("الجولة الثانية أطول وأعمق من الأولى — استثمرا الترقب المتراكم");

  const aftercare: string[] = [
    "حضن طويل دون حركة وتزامن تنفس لثلاث دقائق",
    "قول ثلاثة أشياء محددة أحببتهما في ليلة الليلة — دقّقا في الصياغة",
    "لمسة ترطيب بسيطة (لوشن) وتغطية بالغطاء ثم نوم متلاصق",
    "غداً ليلة جديدة: لا تُحكما على الليلة ولا تقارنها بأخرى",
  ];

  const stages: ProtocolStage[] = [
    { icon: "MessageCircle", title: "الإشارة خلال اليوم", duration: "لحظات متفرقة", details: signal },
    { icon: "Sparkles", title: "تجهيز الأجواء", duration: "10 دقائق", details: setup },
    { icon: "Wine", title: "الافتتاح الرومانسي", duration: "10 دقائق", details: opening },
    {
      icon: "Hand",
      title: `المداعبة الأساسية: ${m1.name}`,
      duration: m1.duration,
      details: [...m1.steps, `إضافة ليلة الليلة: ${m2.name} — ${m2.description}`],
    },
    {
      icon: "Gamepad2",
      title: `لعبة المداعبة: ${game.name}`,
      duration: game.duration,
      details: [game.description, `الأدوات: ${game.tools}`, `القانون: ${game.rule}`],
    },
    { icon: "Heart", title: `الجولة الأولى: ${p1.name}`, duration: "15–20 دقيقة", details: round1 },
    { icon: "BedDouble", title: `الاستراحة والجولة الثانية: ${p2.name}`, duration: "20–25 دقيقة", details: breakRound2 },
    { icon: "Moon", title: "العناية الأخيرة", duration: "10 دقائق", details: aftercare },
  ];

  return stages;
}

/* ------------------------------------------------------------------ */
/*  أدوات مساعدة                                                       */
/* ------------------------------------------------------------------ */

export { pickMethod, pickPosition, pickGame };

export function weekThemeOf(day: number): WeekTheme {
  return WEEKS.find((w) => w.week === weekOf(day))!;
}
