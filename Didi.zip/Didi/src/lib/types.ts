export type Intensity = 1 | 2 | 3 | 4 | 5;

export interface ForeplayMethod {
  id: string;
  name: string;
  intensity: Intensity;
  duration: string;
  description: string;
  steps: string[];
  tip: string;
}

export interface Position {
  id: string;
  name: string;
  intensity: Intensity;
  description: string;
  why: string;
  tip: string;
}

export interface Game {
  id: string;
  name: string;
  intensity: Intensity;
  duration: string;
  tools: string;
  description: string;
  howTo: string[];
  rule: string;
}

export interface ProtocolStage {
  icon: string;
  title: string;
  duration: string;
  details: string[];
}

export interface DayPlan {
  day: number;
  week: number;
  level: Intensity;
  title: string;
  focus: string;
  rounds: string;
  totalDuration: string;
  foreplayMethodIds: string[];
  positionIds: string[];
  gameId: string;
  extraTip: string;
  special?: string;
  specialNote?: string;
}

export interface WeekTheme {
  week: number;
  from: number;
  to: number;
  theme: string;
  description: string;
}

export interface Progress {
  startDate: string | null;
  completedDays: number[];
}
