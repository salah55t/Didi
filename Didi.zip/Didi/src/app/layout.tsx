import type { Metadata } from "next";
import { Cairo } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const cairo = Cairo({
  variable: "--font-cairo",
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700", "800", "900"],
});

export const metadata: Metadata = {
  title: "همسة — رفيق الزوجين لثلاثين ليلة من الحميمية المتجددة",
  description:
    "برنامج حميمي متدرج لثلاثين ليلة للزوجين: بروتوكول متكامل من البداية للنهاية، طرق مداعبة، وضعيات مناسبة، ألعاب حميمية، وتدرّج يومي في مستوى الجرأة لكسر الروتين.",
  keywords: ["الزوجين", "الحميمية", "كسر الروتين", "المداعبة", "برنامج زوجي", "حياة زوجية"],
  robots: { index: false, follow: false },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body className={`${cairo.variable} antialiased min-h-screen flex flex-col`}>
        {children}
        <Toaster />
      </body>
    </html>
  );
}
