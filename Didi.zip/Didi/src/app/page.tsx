"use client";

import { useEffect, useMemo, useState } from "react";
import {
  BookOpen,
  CalendarDays,
  Check,
  Flame,
  Heart,
  Lock,
  MoonStar,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Trophy,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import {
  bestStreak,
  currentDayOf,
  currentStreak,
  loadProgress,
  saveProgress,
  todayISO,
} from "@/lib/progress";
import type { Progress } from "@/lib/types";
import { DayDetail } from "@/components/day-detail";
import { MonthView } from "@/components/month-view";
import { LibraryView } from "@/components/library-view";

export default function Home() {
  const { toast } = useToast();
  const [progress, setProgress] = useState<Progress | null>(null);
  const [tab, setTab] = useState("tonight");
  const [viewDay, setViewDay] = useState(1);

  useEffect(() => {
    const p = loadProgress();
    setProgress(p);
    setViewDay(currentDayOf(p));
  }, []);

  const update = (next: Progress) => {
    saveProgress(next);
    setProgress(next);
  };

  const started = !!progress?.startDate;
  const completedDays = progress?.completedDays ?? [];
  const doneSet = useMemo(() => new Set(completedDays), [completedDays]);
  const streak = useMemo(() => currentStreak(completedDays), [completedDays]);
  const best = useMemo(() => bestStreak(completedDays), [completedDays]);
  const todayNumber = started ? currentDayOf(progress!) : 1;
  const finishedAll = doneSet.has(30) || todayNumber > 30;

  const startProgram = () => {
    update({ startDate: todayISO(), completedDays: [] });
    setViewDay(1);
    setTab("tonight");
    toast({ title: "بدأت الرحلة", description: "ليلة 1 من 30 تنتظركما — بالتوفيق" });
  };

  const toggleDone = (day: number) => {
    if (!progress) return;
    const has = progress.completedDays.includes(day);
    const next = {
      ...progress,
      completedDays: has
        ? progress.completedDays.filter((d) => d !== day)
        : [...progress.completedDays, day].sort((a, b) => a - b),
    };
    update(next);
    if (!has) {
      const complete = next.completedDays.length === 30;
      toast({
        title: complete ? "أكملتما البرنامج كاملاً" : `أُنجزت الليلة ${day}`,
        description: complete
          ? "ثلاثون ليلة من القرب المتجدد — تهانينا الحارة لكما"
          : "استمتعا بالليلة القادمة",
      });
    }
  };

  const restart = () => {
    update({ startDate: todayISO(), completedDays: [] });
    setViewDay(1);
    setTab("tonight");
    toast({ title: "رحلة جديدة تبدأ الآن", description: "أُعيد ضبط البرنامج من الليلة الأولى" });
  };

  return (
    <div className="flex min-h-screen flex-col">
      {/* الرأس */}
      <header className="sticky top-0 z-40 border-b border-border/50 bg-background/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-4xl items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-center gap-2.5">
            <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-rose-500 to-amber-400 rose-glow">
              <Heart className="h-5 w-5 text-white" fill="white" />
            </span>
            <div>
              <h1 className="text-lg font-black leading-tight text-gradient-rose">همسة</h1>
              <p className="text-[11px] font-semibold text-muted-foreground">
                رفيق الزوجين لثلاثين ليلة من القرب المتجدد
              </p>
            </div>
          </div>
          <div className="hidden items-center gap-2 sm:flex">
            <Badge variant="outline" className="border-border/70 text-[11px] text-muted-foreground">
              <Lock className="me-1 h-3 w-3" /> بياناتك على جهازك فقط
            </Badge>
            <Badge variant="outline" className="border-primary/40 text-[11px] text-primary">
              للزوجين البالغين
            </Badge>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-4xl flex-1 px-4 pb-14 pt-6">
        {/* شاشة البداية */}
        {!started && (
          <section className="glass-card relative overflow-hidden rounded-3xl p-6 text-center sm:p-10">
            <div
              className="pointer-events-none absolute -top-24 start-1/2 h-56 w-56 -translate-x-1/2 rounded-full bg-primary/25 blur-3xl"
              aria-hidden
            />
            <span className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-rose-500 to-amber-400 rose-glow">
              <MoonStar className="h-8 w-8 text-white" />
            </span>
            <h2 className="text-2xl font-black text-gradient-rose sm:text-3xl">
              رحلة ثلاثين ليلة لكسر الروتين
            </h2>
            <p className="mx-auto mt-3 max-w-xl text-sm leading-7 text-foreground/80">
              برنامج متدرج كامل للزوجين: كل ليلة يصلك بروتوكول متكامل من الإشارة الصباحية حتى
              العناية الأخيرة — مع عدد الجولات المقترح، طريقة المداعبة، الوضعيتان المناسبتان،
              ولعبة حميمية مختلفة، وجرأة تصعد يوماً بعد يوماً بسلام وأمان.
            </p>
            <div className="mx-auto mt-6 grid max-w-2xl gap-3 text-start sm:grid-cols-3">
              {[
                {
                  icon: Sparkles,
                  title: "بروتوكول متكامل",
                  desc: "ثماني مراحل من البداية للنهاية في كل ليلة",
                },
                {
                  icon: Flame,
                  title: "تدرّج في الجرأة",
                  desc: "خمسة مستويات تصعد تدريجياً عبر أربعة أسابيع",
                },
                {
                  icon: Trophy,
                  title: "محتوى متنوع",
                  desc: "16 مداعبة، 16 وضعية، و12 لعبة حميمية",
                },
              ].map(({ icon: Icon, title, desc }) => (
                <div key={title} className="rounded-2xl border border-border/50 bg-card/60 p-4">
                  <Icon className="mb-2 h-5 w-5 text-primary" />
                  <h3 className="mb-1 text-sm font-extrabold">{title}</h3>
                  <p className="text-xs leading-6 text-muted-foreground">{desc}</p>
                </div>
              ))}
            </div>
            <div className="mt-7 flex flex-col items-center gap-3">
              <Button
                size="lg"
                onClick={startProgram}
                className="min-h-12 bg-gradient-to-l from-rose-600 to-amber-500 px-10 text-base font-extrabold text-white hover:opacity-90"
              >
                <Heart className="me-2 h-5 w-5" fill="white" />
                ابدأ رحلة الثلاثين ليلة الليلة
              </Button>
              <Button
                variant="ghost"
                onClick={() => setTab("library")}
                className="text-sm text-muted-foreground"
              >
                <BookOpen className="me-2 h-4 w-4" />
                تصفّح المكتبة أولاً دون بدء البرنامج
              </Button>
            </div>
          </section>
        )}

        {/* لوحة التقدم */}
        {started && (
          <section className="glass-card mb-6 rounded-3xl p-5">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
              <h2 className="flex items-center gap-2 text-sm font-extrabold text-foreground">
                <Trophy className="h-4 w-4 text-amber-400" />
                تقدّم الرحلة
              </h2>
              <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
                <Badge className="border-0 bg-primary/15 text-primary">
                  <Check className="me-1 h-3 w-3" /> {completedDays.length} من 30 ليلة
                </Badge>
                <Badge className="border-0 bg-amber-500/15 text-amber-300">
                  <Flame className="me-1 h-3 w-3" /> سلسلة {streak} ليلة
                </Badge>
                <Badge className="border-0 bg-emerald-500/15 text-emerald-300">
                  أفضل سلسلة {best}
                </Badge>
              </div>
            </div>
            <Progress value={(completedDays.length / 30) * 100} className="h-2.5" />
            <p className="mt-2.5 text-xs text-muted-foreground">
              {finishedAll
                ? "أنهيتما الثلاثين ليلة كاملة — إنه إنجاز يستحق الاحتفال. أتشوّعان ببداية جديدة؟"
                : `أنتما الآن في الليلة ${todayNumber} — التزموا بها الليلة إن استطعتم، وتبادلا الإحساس بصدق.`}
            </p>
          </section>
        )}

        {/* التبويبات */}
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="mx-auto grid w-full max-w-xl grid-cols-3 h-auto p-1">
            <TabsTrigger value="tonight" className="gap-1.5 py-2 text-xs sm:text-sm">
              <MoonStar className="h-4 w-4" /> ليلة اليوم
            </TabsTrigger>
            <TabsTrigger value="month" className="gap-1.5 py-2 text-xs sm:text-sm">
              <CalendarDays className="h-4 w-4" /> البرنامج الشهري
            </TabsTrigger>
            <TabsTrigger value="library" className="gap-1.5 py-2 text-xs sm:text-sm">
              <BookOpen className="h-4 w-4" /> المكتبة
            </TabsTrigger>
          </TabsList>

          {/* ليلة اليوم */}
          <TabsContent value="tonight" className="mt-6 space-y-6">
            {started ? (
              <>
                <div className="flex items-center justify-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={viewDay <= 1}
                    onClick={() => setViewDay((d) => Math.max(1, d - 1))}
                  >
                    الليلة السابقة
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setViewDay(todayNumber);
                    }}
                    className="border-primary/40 text-primary"
                  >
                    ليلة اليوم ({todayNumber})
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={viewDay >= 30}
                    onClick={() => setViewDay((d) => Math.min(30, d + 1))}
                  >
                    الليلة التالية
                  </Button>
                </div>

                {finishedAll ? (
                  <section className="glass-card rounded-3xl p-8 text-center">
                    <Trophy className="mx-auto mb-3 h-12 w-12 text-amber-400" />
                    <h2 className="text-xl font-black text-gradient-rose">
                      أكملتما رحلة الثلاثين ليلة
                    </h2>
                    <p className="mx-auto mt-2 max-w-md text-sm leading-7 text-muted-foreground">
                      استرجعوا ليلتكم المفضلة من التقويم الشهري متى شئتما، أو ابدؤوا رحلة جديدة
                      بمستوى أعلى من الثقة والمعرفة المتبادلة.
                    </p>
                    <Button onClick={restart} className="mt-5 min-h-11 bg-primary text-primary-foreground">
                      <RefreshCw className="me-2 h-4 w-4" /> ابدأ رحلة جديدة
                    </Button>
                  </section>
                ) : (
                  <DayDetail
                    day={viewDay}
                    done={doneSet.has(viewDay)}
                    onToggleDone={() => toggleDone(viewDay)}
                  />
                )}
              </>
            ) : (
              <section className="glass-card rounded-3xl p-8 text-center">
                <MoonStar className="mx-auto mb-3 h-10 w-10 text-primary" />
                <h3 className="text-lg font-extrabold">البرنامج لم يبدأ بعد</h3>
                <p className="mx-auto mt-2 max-w-md text-sm leading-7 text-muted-foreground">
                  ابدأ الرحلة لتظهر لك ليلة الليلة بكل تفاصيلها: البروتوكول، المداعبة، الوضعيات،
                  واللعبة — أو تصفّح المكتبة والبرنامج بحرّية أولاً.
                </p>
                <div className="mt-5 flex flex-wrap justify-center gap-2">
                  <Button onClick={startProgram} className="min-h-11 bg-gradient-to-l from-rose-600 to-amber-500 font-bold text-white">
                    ابدأ الآن
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setTab("month")}
                    className="min-h-11 font-bold"
                  >
                    استعرض التقويم
                  </Button>
                </div>
              </section>
            )}
          </TabsContent>

          {/* البرنامج الشهري */}
          <TabsContent value="month" className="mt-6">
            <MonthView activeDay={started ? todayNumber : 0} completedDays={completedDays} onToggleDone={toggleDone} />
          </TabsContent>

          {/* المكتبة */}
          <TabsContent value="library" className="mt-6">
            <LibraryView />
          </TabsContent>
        </Tabs>
      </main>

      {/* التذييل */}
      <footer className="mt-auto border-t border-border/50 bg-background/60 backdrop-blur-xl">
        <div className="mx-auto max-w-4xl space-y-3 px-4 py-6 text-center">
          <p className="text-xs leading-6 text-muted-foreground">
            المحتوى موجّه حصرياً للزوجين البالغين بالتراضي المتبادل الكامل. كل اقتراح قابل
            للتعديل حسب راحة الطرفين، والرفض المتبادل دائماً خيار محترم ومقدّس.
          </p>
          <p className="flex flex-wrap items-center justify-center gap-1.5 text-xs font-semibold text-foreground/60">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
            لا حسابات ولا خوادم: تقدّمكما محفوظ في متصفحك فقط ولا يغادر جهازك أبداً.
          </p>
          {started && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="sm" className="text-xs text-muted-foreground">
                  <RefreshCw className="me-1.5 h-3.5 w-3.5" /> إعادة ضبط البرنامج من البداية
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="border-border/60 bg-card">
                <AlertDialogHeader>
                  <AlertDialogTitle>إعادة ضبط البرنامج؟</AlertDialogTitle>
                  <AlertDialogDescription>
                    ستُمحى كل أيامكما المكتملة وتعود الرحلة إلى الليلة الأولى. هذا الإجراء لا
                    يمكن التراجع عنه.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>تراجع</AlertDialogCancel>
                  <AlertDialogAction onClick={restart} className="bg-primary text-primary-foreground">
                    نعم، ابدأ من جديد
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>
      </footer>
    </div>
  );
}
